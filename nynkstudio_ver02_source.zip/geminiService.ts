
import { GoogleGenAI } from "@google/genai";
import { ImageSize, AspectRatio } from "./types";
import { DEFAULT_POSITIVE_PROMPT, DEFAULT_NEGATIVE_PROMPT, APP_MODEL, ARCHITECT_MODEL, ARCHITECT_SYSTEM_INSTRUCTION } from "./constants";

const resizeImage = (base64Str: string): Promise<string> => {
  return new Promise((resolve) => {
    const img = new Image();
    img.src = `data:image/jpeg;base64,${base64Str}`;
    img.onload = () => {
      const canvas = document.createElement("canvas");
      let width = img.width;
      let height = img.height;
      const MAX_SIZE = 1024;

      if (width > height) {
        if (width > MAX_SIZE) {
          height *= MAX_SIZE / width;
          width = MAX_SIZE;
        }
      } else {
        if (height > MAX_SIZE) {
          width *= MAX_SIZE / height;
          height = MAX_SIZE;
        }
      }

      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext("2d");
      if (!ctx) {
        resolve(base64Str); // Fallback if context fails
        return;
      }
      ctx.drawImage(img, 0, 0, width, height);
      // Compress to jpeg 0.8 for speed
      resolve(canvas.toDataURL("image/jpeg", 0.8).split(",")[1]);
    };
    img.onerror = () => {
      console.warn("Image resize failed, using original");
      resolve(base64Str); // Fail gracefully
    };
  });
};

export const generateImage = async (
  apiKey: string,
  userPrompt: string,
  images: { data: string; mimeType: string }[],
  config: { size: ImageSize; aspectRatio: AspectRatio; consistencyFixed: boolean }
) => {
  const ai = new GoogleGenAI({ apiKey });

  // Combine prompt logic
  let fullPrompt = "";
  if (config.consistencyFixed) {
    fullPrompt = `CONSISTENCY INSTRUCTION: You are in 'Strict Asset Preservation' mode.
    1. The FIRST image provided is the MASTER REFERENCE.
    2. KEY OBJECTIVE: You must PRESERVE the master image's exact composition, assets, layout, and lighting.
    3. only modify specific elements explicitly requested in the prompt: "${userPrompt}".
    4. DO NOT creatively reimagine or hallucinate new details. DO NOT change the camera angle or perspective unless explicitly asked.
    5. Everything NOT mentioned in the prompt must remain PIXEL-PERFECT identical to the reference.
    6. Treat the reference image as the absolute ground truth.
    7. EXCEPTION: If the user asks to change the BACKGROUND (e.g., "white background"), you must isolate the foreground subjects (people, items) EXACTLY as they are, and replace ONLY the environment. Do not create a new room/architecture if a solid color is requested.`;

    // CRITICAL OVERRIDE for solid background requests
    if (/white background|solid background|remove background|clean background|배경 제거|흰색 배경|누끼/i.test(userPrompt)) {
      fullPrompt += `
      \n[CRITICAL PRIORITY INSTRUCTION]
      The user explicitly requested a CLEAN/SOLID background.
      1. STOP generating "rooms", "walls", "floors", or "perspective lines".
      2. The background must be FLAT and 2D.
      3. If "white background" is requested, make it PURE WHITE (#FFFFFF) with NO shadows, NO corner lines, and NO horizon line.
      4. IGNORE specific lighting preservation if it creates floor shadows. Use flat commercial studio lighting.
      5. This instruction OVERRIDES any "architectural style" or "room preservation" rules.`;
    }
  } else {
    fullPrompt = `Generate a high-quality architectural image based on this description: "${userPrompt}".
    Apply a minimalist, high-end, photorealistic aesthetic. Style Guide: ${DEFAULT_POSITIVE_PROMPT}. Avoid: ${DEFAULT_NEGATIVE_PROMPT}`;
  }

  // Prompt construction is handled above. Sending request...

  const parts = [
    ...await Promise.all(images.map(async (img) => ({
      inlineData: {
        data: await resizeImage(img.data),
        mimeType: "image/jpeg",
      },
    }))),
    { text: fullPrompt },
  ];

  try {
    const response = await ai.models.generateContent({
      model: APP_MODEL,
      contents: { parts },
      config: {
        imageConfig: {
          aspectRatio: config.aspectRatio,
          imageSize: config.size,
        },
      },
    });

    if (!response.candidates?.[0]?.content?.parts) {
      throw new Error("No candidates returned from the model.");
    }

    // Find the image part as it may not be the first part.
    const imagePart = response.candidates[0].content.parts.find(p => p.inlineData);
    if (!imagePart || !imagePart.inlineData) {
      throw new Error("No image data found in the response.");
    }

    return `data:${imagePart.inlineData.mimeType};base64,${imagePart.inlineData.data}`;
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
};

// ==========================================
// NEW: AI Architect Logic (v2.5 Integration)
// ==========================================

export const generateSpatialConcept = async (apiKey: string, userInput: string): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey });

  try {
    const response = await ai.models.generateContent({
      model: ARCHITECT_MODEL,
      config: {
        systemInstruction: ARCHITECT_SYSTEM_INSTRUCTION,
        temperature: 0.7,
        maxOutputTokens: 500,
      },
      contents: [
        {
          role: "user",
          parts: [{ text: userInput }]
        }
      ]
    });

    // Handle potential response structure (GoogleGenAI SDK specifics)
    const text = response.candidates?.[0]?.content?.parts?.[0]?.text;

    if (!text) {
      throw new Error("No text response from Architect.");
    }

    return text;
  } catch (error) {
    console.error("AI Architect Error:", error);
    return "SYSTEM_HALTED: Neural link unstable.";
  }
};
