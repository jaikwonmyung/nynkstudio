
import React, { useState, useCallback, useRef, useEffect } from 'react';
import { generateImage } from './geminiService';
import { ReferenceImage, GenerationResult, ImageSize, AspectRatio } from './types';

// Extend window for AI Studio functionality using the expected AIStudio type
declare global {
  interface AIStudio {
    hasSelectedApiKey: () => Promise<boolean>;
    openSelectKey: () => Promise<void>;
  }

  interface Window {
    // Removed readonly modifier to match existing declarations and fix identical modifiers error.
    aistudio: AIStudio;
  }
}

const App: React.FC = () => {
  const [prompt, setPrompt] = useState<string>('');
  const [ref1, setRef1] = useState<ReferenceImage | null>(null);
  const [ref2, setRef2] = useState<ReferenceImage | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [result, setResult] = useState<GenerationResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [previewMode, setPreviewMode] = useState<'fit' | 'fill'>('fill');
  const [imageSize, setImageSize] = useState<ImageSize>('1K');
  const [hasKey, setHasKey] = useState<boolean | null>(null);
  const [isDragging1, setIsDragging1] = useState(false);
  const [isDragging2, setIsDragging2] = useState(false);

  const fileInputRef1 = useRef<HTMLInputElement>(null);
  const fileInputRef2 = useRef<HTMLInputElement>(null);

  useEffect(() => {
    checkApiKey();
  }, []);

  const checkApiKey = async () => {
    try {
      const selected = await window.aistudio.hasSelectedApiKey();
      setHasKey(selected);
    } catch (e) {
      setHasKey(false);
    }
  };

  const handleOpenKeySelector = async () => {
    await window.aistudio.openSelectKey();
    setHasKey(true);
  };

  const processFile = (file: File, slot: 1 | 2) => {
    if (!file || !file.type.startsWith('image/')) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      const base64String = (reader.result as string).split(',')[1];
      const newRef: ReferenceImage = {
        id: Math.random().toString(36).substr(2, 9),
        file,
        previewUrl: URL.createObjectURL(file),
        base64Data: base64String,
        mimeType: file.type,
      };
      if (slot === 1) setRef1(newRef);
      else setRef2(newRef);
    };
    reader.readAsDataURL(file);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, slot: 1 | 2) => {
    const file = e.target.files?.[0];
    if (file) processFile(file, slot);
  };

  const onDragOver = (e: React.DragEvent, slot: 1 | 2) => {
    e.preventDefault();
    if (slot === 1) setIsDragging1(true);
    else setIsDragging2(true);
  };

  const onDragLeave = (e: React.DragEvent, slot: 1 | 2) => {
    e.preventDefault();
    if (slot === 1) setIsDragging1(false);
    else setIsDragging2(false);
  };

  const onDrop = (e: React.DragEvent, slot: 1 | 2) => {
    e.preventDefault();
    if (slot === 1) setIsDragging1(false);
    else setIsDragging2(false);

    const file = e.dataTransfer.files?.[0];
    if (file) processFile(file, slot);
  };

  const handleGenerate = async () => {
    if (isGenerating) return;
    setIsGenerating(true);
    setError(null);

    const imagesToPass = [];
    if (ref1) imagesToPass.push({ data: ref1.base64Data, mimeType: ref1.mimeType });
    if (ref2) imagesToPass.push({ data: ref2.base64Data, mimeType: ref2.mimeType });

    try {
      const imageUrl = await generateImage(prompt, imagesToPass, {
        size: imageSize,
        aspectRatio: '16:9',
      });
      setResult({
        imageUrl,
        prompt,
        timestamp: Date.now(),
      });
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Generation failed. Please try again.');
      if (err.message?.includes("Requested entity was not found")) {
        setHasKey(false);
      }
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDownload = () => {
    if (!result) return;
    const link = document.createElement('a');
    link.href = result.imageUrl;
    link.download = `nynk-realistic-${Date.now()}.png`;
    link.click();
  };

  if (hasKey === false) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-zinc-950 p-6">
        <div className="max-w-md w-full text-center space-y-6 bg-zinc-900 p-8 rounded-2xl border border-zinc-800 shadow-2xl">
          <div className="w-20 h-20 bg-zinc-100/10 rounded-full flex items-center justify-center mx-auto text-zinc-100">
            <i className="fa-solid fa-camera-retro text-4xl"></i>
          </div>
          <h1 className="text-2xl font-bold tracking-tighter uppercase">API Authentication</h1>
          <p className="text-zinc-400 text-sm">
            Professional high-fidelity imaging requires a valid Gemini 3 Pro API key from a paid GCP project.
          </p>
          <a 
            href="https://ai.google.dev/gemini-api/docs/billing" 
            target="_blank" 
            rel="noreferrer"
            className="text-xs text-zinc-500 hover:text-zinc-300 underline block"
          >
            Billing Documentation
          </a>
          <button 
            onClick={handleOpenKeySelector}
            className="w-full py-4 bg-zinc-100 hover:bg-zinc-200 text-zinc-950 transition-colors rounded-xl font-bold uppercase tracking-widest text-xs"
          >
            Authorize Access
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 pb-20">
      {/* Header */}
      <header className="border-b border-zinc-800 py-6 px-8 flex justify-between items-center bg-zinc-950/50 backdrop-blur-xl sticky top-0 z-50">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-zinc-100 rounded-lg flex items-center justify-center shadow-lg shadow-white/5">
            <i className="fa-solid fa-building text-zinc-950"></i>
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tighter uppercase">nynk AI</h1>
            <p className="text-[10px] text-zinc-500 uppercase tracking-[0.2em] font-bold">Architectural Vision Engine</p>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <select 
            value={imageSize}
            onChange={(e) => setImageSize(e.target.value as ImageSize)}
            className="bg-zinc-900 border border-zinc-800 text-xs font-bold uppercase tracking-widest px-4 py-2 rounded-lg focus:outline-none focus:ring-1 focus:ring-zinc-600 appearance-none cursor-pointer"
          >
            <option value="1K">1K RAW</option>
            <option value="2K">2K RAW</option>
            <option value="4K">4K RAW</option>
          </select>
          <button 
            className="text-zinc-500 hover:text-white transition-colors p-2"
            onClick={handleOpenKeySelector}
          >
            <i className="fa-solid fa-sliders"></i>
          </button>
        </div>
      </header>

      <main className="max-w-[1600px] mx-auto px-8 mt-10 grid grid-cols-1 lg:grid-cols-12 gap-10">
        {/* Left Column: Inputs */}
        <div className="lg:col-span-5 space-y-8">
          {/* Prompt Section */}
          <section className="space-y-4">
            <label className="text-[10px] font-bold text-zinc-500 flex items-center gap-2 uppercase tracking-[0.2em]">
              <i className="fa-solid fa-pen-nib text-zinc-100"></i>
              Conceptual Description
            </label>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="OMA 스타일의 미니멀한 공간, 거친 콘크리트 질감, 세련된 유리 파사드 등 건축적 요소를 입력하세요..."
              className="w-full h-48 bg-zinc-900 border border-zinc-800 rounded-xl p-6 text-zinc-200 focus:ring-1 focus:ring-zinc-600 focus:border-transparent outline-none resize-none transition-all placeholder:text-zinc-600 text-sm leading-relaxed"
            />
          </section>

          {/* Reference Images Section with Drag & Drop */}
          <section className="space-y-4">
            <label className="text-[10px] font-bold text-zinc-500 flex items-center gap-2 uppercase tracking-[0.2em]">
              <i className="fa-solid fa-camera text-zinc-100"></i>
              Visual Archetypes
            </label>
            <div className="grid grid-cols-2 gap-4">
              {/* Slot 1 */}
              <div 
                onClick={() => fileInputRef1.current?.click()}
                onDragOver={(e) => onDragOver(e, 1)}
                onDragLeave={(e) => onDragLeave(e, 1)}
                onDrop={(e) => onDrop(e, 1)}
                className={`group relative aspect-square rounded-xl border border-zinc-800 transition-all cursor-pointer overflow-hidden flex flex-col items-center justify-center 
                  ${ref1 ? 'border-zinc-500 bg-zinc-900' : 'hover:border-zinc-600 hover:bg-zinc-900/50'}
                  ${isDragging1 ? 'border-zinc-100 bg-zinc-800' : ''}`}
              >
                {ref1 ? (
                  <>
                    <img src={ref1.previewUrl} className="w-full h-full object-cover grayscale" alt="Ref 1" />
                    <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                      <span className="text-[10px] font-bold tracking-[0.2em]">REPLACE</span>
                    </div>
                  </>
                ) : (
                  <div className="text-center p-4">
                    <i className="fa-solid fa-layer-group text-zinc-800 text-2xl mb-3"></i>
                    <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Aesthetic</p>
                  </div>
                )}
                <input ref={fileInputRef1} type="file" className="hidden" accept="image/png, image/jpeg" onChange={(e) => handleFileChange(e, 1)} />
              </div>

              {/* Slot 2 */}
              <div 
                onClick={() => fileInputRef2.current?.click()}
                onDragOver={(e) => onDragOver(e, 2)}
                onDragLeave={(e) => onDragLeave(e, 2)}
                onDrop={(e) => onDrop(e, 2)}
                className={`group relative aspect-square rounded-xl border border-zinc-800 transition-all cursor-pointer overflow-hidden flex flex-col items-center justify-center 
                  ${ref2 ? 'border-zinc-500 bg-zinc-900' : 'hover:border-zinc-600 hover:bg-zinc-900/50'}
                  ${isDragging2 ? 'border-zinc-100 bg-zinc-800' : ''}`}
              >
                {ref2 ? (
                  <>
                    <img src={ref2.previewUrl} className="w-full h-full object-cover grayscale" alt="Ref 2" />
                    <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                      <span className="text-[10px] font-bold tracking-[0.2em]">REPLACE</span>
                    </div>
                  </>
                ) : (
                  <div className="text-center p-4">
                    <i className="fa-solid fa-vector-square text-zinc-800 text-2xl mb-3"></i>
                    <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Structure</p>
                  </div>
                )}
                <input ref={fileInputRef2} type="file" className="hidden" accept="image/png, image/jpeg" onChange={(e) => handleFileChange(e, 2)} />
              </div>
            </div>
            <div className="flex items-center gap-2 p-3 bg-zinc-900/30 rounded-lg border border-zinc-800/50">
              <i className="fa-solid fa-circle-info text-[10px] text-zinc-600"></i>
              <p className="text-[9px] text-zinc-500 uppercase tracking-widest font-bold">
                DRAG & DROP REFERENCE PLATES TO GUIDE REALISTIC RENDERING.
              </p>
            </div>
          </section>

          {/* Action Button */}
          <button
            onClick={handleGenerate}
            disabled={isGenerating}
            className={`w-full py-5 rounded-xl font-bold text-xs tracking-[0.3em] flex items-center justify-center gap-3 transition-all uppercase ${isGenerating ? 'bg-zinc-900 text-zinc-700 cursor-not-allowed border border-zinc-800' : 'bg-zinc-100 hover:bg-white text-zinc-950 shadow-xl shadow-white/5 active:scale-[0.99]'}`}
          >
            {isGenerating ? (
              <>
                <i className="fa-solid fa-circle-notch animate-spin"></i>
                Processing Imagery
              </>
            ) : (
              <>
                Generate Realistic View
              </>
            )}
          </button>

          {error && (
            <div className="bg-red-500/5 border border-red-500/20 text-red-400 p-4 rounded-xl text-[10px] font-bold uppercase tracking-widest flex gap-3">
              <i className="fa-solid fa-circle-exclamation"></i>
              <p>{error}</p>
            </div>
          )}

          {/* Technical Specs */}
          <div className="bg-zinc-950 p-6 rounded-2xl border border-zinc-900 space-y-5">
            <h3 className="text-[9px] font-bold text-zinc-600 tracking-[0.3em] uppercase border-b border-zinc-900 pb-3">Compute Pipeline</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between text-[10px] font-bold tracking-widest">
                <span className="text-zinc-500">STYLE</span>
                <span className="text-zinc-300">OMA ARCHITECTURAL PHOTO</span>
              </div>
              <div className="flex items-center justify-between text-[10px] font-bold tracking-widest">
                <span className="text-zinc-500">ENGINE</span>
                <span className="text-zinc-300">NYNK REAL-PHOTO v1.2</span>
              </div>
              <div className="flex items-center justify-between text-[10px] font-bold tracking-widest">
                <span className="text-zinc-500">FORMAT</span>
                <span className="text-zinc-300">16:9 RAW DATA</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Results */}
        <div className="lg:col-span-7 flex flex-col h-full">
          <div className="flex-1 min-h-[500px] bg-zinc-900/50 rounded-3xl border border-zinc-800/50 flex flex-col overflow-hidden relative group">
            <div className="absolute top-6 left-6 z-10 flex gap-2">
              <button 
                onClick={() => setPreviewMode('fill')}
                className={`px-4 py-2 rounded-lg text-[10px] font-bold tracking-widest uppercase transition-all ${previewMode === 'fill' ? 'bg-zinc-100 text-zinc-950' : 'bg-zinc-950/50 text-zinc-500 hover:text-zinc-300 backdrop-blur-md'}`}
              >
                Perspective
              </button>
              <button 
                onClick={() => setPreviewMode('fit')}
                className={`px-4 py-2 rounded-lg text-[10px] font-bold tracking-widest uppercase transition-all ${previewMode === 'fit' ? 'bg-zinc-100 text-zinc-950' : 'bg-zinc-950/50 text-zinc-500 hover:text-zinc-300 backdrop-blur-md'}`}
              >
                Detail
              </button>
            </div>

            {result ? (
              <div className="flex-1 flex items-center justify-center p-8">
                <div className={`relative transition-all duration-700 ease-in-out shadow-2xl shadow-black overflow-hidden rounded-lg bg-zinc-950 border border-zinc-800 ${previewMode === 'fill' ? 'w-full aspect-video' : 'h-full aspect-square'}`}>
                  <img 
                    src={result.imageUrl} 
                    className="w-full h-full object-cover"
                    alt="Generation Result" 
                  />
                  <div className="absolute bottom-6 right-6 flex gap-3 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button 
                      onClick={handleDownload}
                      className="px-6 py-3 bg-zinc-100 text-zinc-950 text-[10px] font-black tracking-[0.2em] rounded-lg flex items-center gap-2 hover:bg-white transition-colors uppercase"
                    >
                      <i className="fa-solid fa-cloud-arrow-down"></i>
                      Extract RAW
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center text-zinc-800 space-y-8">
                <div className="relative">
                   <div className={`w-24 h-24 border border-zinc-800 rounded-full flex items-center justify-center transition-all ${isGenerating ? 'scale-110 border-zinc-700' : ''}`}>
                      <i className={`fa-solid fa-camera-aperture text-2xl ${isGenerating ? 'animate-spin text-zinc-600' : 'text-zinc-800'}`}></i>
                   </div>
                   {isGenerating && <div className="absolute -inset-4 border border-zinc-800 border-t-zinc-400 rounded-full animate-spin"></div>}
                </div>
                <div className="text-center space-y-3 max-w-sm px-8">
                  <h3 className="text-xs font-bold text-zinc-600 uppercase tracking-[0.4em]">{isGenerating ? 'Synthesizing Vision' : 'Standby'}</h3>
                  <p className="text-[10px] leading-relaxed tracking-wider text-zinc-700 uppercase">
                    {isGenerating 
                      ? 'Analyzing archetypes and depth maps to synthesize high-fidelity architectural imagery.' 
                      : 'Input conceptual descriptors and architectural archetypes to begin synthesis.'}
                  </p>
                </div>
              </div>
            )}
            
            {result && !isGenerating && (
              <div className="p-8 bg-zinc-950/90 backdrop-blur-2xl border-t border-zinc-800/50 flex justify-between items-center">
                 <div>
                    <p className="text-[9px] font-bold text-zinc-500 uppercase tracking-[0.3em]">Computed Output</p>
                    <h4 className="text-[11px] font-bold mt-1 text-zinc-400 uppercase tracking-widest">{imageSize} Architectural View</h4>
                 </div>
                 <button 
                  onClick={() => setResult(null)}
                  className="text-zinc-600 hover:text-zinc-100 transition-colors text-[9px] font-bold uppercase tracking-widest flex items-center gap-2"
                 >
                   <i className="fa-solid fa-arrows-rotate"></i>
                   Re-compute
                 </button>
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Mobile Footer */}
      <footer className="fixed bottom-0 left-0 right-0 p-4 bg-zinc-950/90 backdrop-blur-2xl border-t border-zinc-800 lg:hidden z-50">
         <button
            onClick={handleGenerate}
            disabled={isGenerating}
            className={`w-full py-4 rounded-xl font-bold text-[10px] tracking-[0.3em] flex items-center justify-center gap-3 transition-all uppercase ${isGenerating ? 'bg-zinc-900 text-zinc-700 border border-zinc-800' : 'bg-zinc-100 text-zinc-950'}`}
          >
            {isGenerating ? <i className="fa-solid fa-circle-notch animate-spin"></i> : <i className="fa-solid fa-camera"></i>}
            {isGenerating ? 'SYNTHESIZING...' : 'RENDER VIEW'}
          </button>
      </footer>
    </div>
  );
};

export default App;
