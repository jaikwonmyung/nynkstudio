
import { GoogleGenAI } from "@google/genai";
import { ImageSize, AspectRatio } from "./types";
import { DEFAULT_POSITIVE_PROMPT, DEFAULT_NEGATIVE_PROMPT, APP_MODEL } from "./constants";

export const generateImage = async (
  userPrompt: string,
  images: { data: string; mimeType: string }[],
  config: { size: ImageSize; aspectRatio: AspectRatio }
) => {
  // Always initialize with process.env.API_KEY directly as per guidelines.
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  // Combine prompt logic
  const fullPrompt = `${userPrompt}. Style Guide: ${DEFAULT_POSITIVE_PROMPT}. Avoid: ${DEFAULT_NEGATIVE_PROMPT}`;

  const parts = [
    ...images.map(img => ({
      inlineData: {
        data: img.data,
        mimeType: img.mimeType,
      },
    })),
    { text: fullPrompt },
  ];

  try {
    const response = await ai.models.generateContent({
      model: APP_MODEL,
      contents: { parts },
      config: {
        imageConfig: {
          aspectRatio: config.aspectRatio,
          imageSize: config.size,
        },
      },
    });

    if (!response.candidates?.[0]?.content?.parts) {
      throw new Error("No candidates returned from the model.");
    }

    // Find the image part as it may not be the first part.
    const imagePart = response.candidates[0].content.parts.find(p => p.inlineData);
    if (!imagePart || !imagePart.inlineData) {
      throw new Error("No image data found in the response.");
    }

    return `data:${imagePart.inlineData.mimeType};base64,${imagePart.inlineData.data}`;
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
};
