
import React, { useState, useRef, useEffect } from 'react';
import { generateImage } from './geminiService';
import { ReferenceImage, GenerationResult, ImageSize, AspectRatio } from './types';
import LoginPage from './src/components/LoginPage';
import SettingsModal from './src/components/SettingsModal';

const App: React.FC = () => {
  const [prompt, setPrompt] = useState<string>('');
  const [references, setReferences] = useState<ReferenceImage[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isConsistencyFixed, setIsConsistencyFixed] = useState(false);



  const [result, setResult] = useState<GenerationResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [previewMode, setPreviewMode] = useState<'fit' | 'fill'>('fill');
  const [imageSize, setImageSize] = useState<ImageSize>('1K');
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>('16:9');
  const [generationCredits, setGenerationCredits] = useState(10);
  const [apiKey, setApiKey] = useState<string | null>(null);
  const [showKeyModal, setShowKeyModal] = useState(false);
  const [tempKey, setTempKey] = useState('');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [draggingSlot, setDraggingSlot] = useState<number | 'add' | null>(null);

  // We only need one ref for the "add" button, and we can reuse it or create a map if we want to replace specific indices.
  // For simplicity, let's have one main input for adding, and maybe individual inputs for replacing?
  // Actually, usually "Add" is enough. If user wants to replace, they can remove and add?
  // "Replace" was a feature before. Let's keep "Replace" by triggering a click on a specific hidden input if needed.
  // Ease of use: One hidden input ref is enough if we track "which index triggers it".
  const fileInputRef = useRef<HTMLInputElement>(null);
  const activeIndexRef = useRef<number | null>(null); // null means "add new"

  useEffect(() => {
    const storedKey = localStorage.getItem('gemini_api_key');
    if (storedKey) {
      setApiKey(storedKey);
    } else {
      setShowKeyModal(true);
    }
  }, []);

  const handleSaveKey = () => {
    if (!tempKey.trim()) return;
    localStorage.setItem('gemini_api_key', tempKey);
    setApiKey(tempKey);
    setShowKeyModal(false);
  };

  const handleClearKey = () => {
    localStorage.removeItem('gemini_api_key');
    setApiKey(null);
    setTempKey('');
    setShowKeyModal(true);
  };

  const processFile = (file: File, index: number | null) => {
    if (!file || !file.type.startsWith('image/')) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      const base64String = (reader.result as string).split(',')[1];
      const newRef: ReferenceImage = {
        id: Math.random().toString(36).substring(2, 9),
        file,
        previewUrl: URL.createObjectURL(file),
        base64Data: base64String,
        mimeType: file.type,
      };

      setReferences(prev => {
        if (index === null) {
          // Add new
          return [...prev, newRef];
        } else {
          // Replace existing
          const newRefs = [...prev];
          newRefs[index] = newRef;
          return newRefs;
        }
      });
    };
    reader.readAsDataURL(file);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processFile(file, activeIndexRef.current);
    }
    // Reset inputs
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleTriggerFile = (index: number | null) => {
    activeIndexRef.current = index;
    fileInputRef.current?.click();
  };

  const removeReference = (index: number, e: React.MouseEvent) => {
    e.stopPropagation();
    setReferences(prev => prev.filter((_, i) => i !== index));
  };


  const onDragOver = (e: React.DragEvent, index: number | 'add') => {
    e.preventDefault();
    setDraggingSlot(index);
  };

  const onDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setDraggingSlot(null);
  };

  const onDrop = (e: React.DragEvent, index: number | 'add') => {
    e.preventDefault();
    setDraggingSlot(null);

    const file = e.dataTransfer.files?.[0];
    if (file) processFile(file, index === 'add' ? null : index);
  };

  const [history, setHistory] = useState<GenerationResult[]>([]);

  // Load history on mount
  useEffect(() => {
    // SAFETY PATCH: Clear potentially corrupted history to fix White Screen
    // Remove this after verification
    try {
      const saved = localStorage.getItem('nynk_history');
      if (saved) {
        const parsed = JSON.parse(saved);
        // Verify structure deeply or just reset if we suspect corruption
        // For now, let's allow loading but wrapped safely.
        if (Array.isArray(parsed)) {
          setHistory(parsed);
        }
      }
    } catch (e) {
      console.error("History corrupted, resetting", e);
      localStorage.removeItem('nynk_history');
      setHistory([]);
    }
  }, []);

  const addToHistory = (newResult: GenerationResult) => {
    const updated = [newResult, ...history].slice(0, 20); // Keep last 20
    setHistory(updated);
    localStorage.setItem('nynk_history', JSON.stringify(updated));
  };

  const handleGenerate = async () => {
    if (isGenerating) return;
    setIsGenerating(true);
    setError(null);

    const imagesToPass = references.map(ref => ({
      data: ref.base64Data,
      mimeType: ref.mimeType
    }));

    try {
      if (!apiKey) {
        setShowKeyModal(true);
        return;
      }

      const imageUrl = await generateImage(apiKey, prompt, imagesToPass, {
        size: imageSize,
        aspectRatio: aspectRatio,
        consistencyFixed: isConsistencyFixed
      });

      // Credit deduction removed as per user request

      const newResult = {
        imageUrl,
        prompt,
        timestamp: Date.now(),
      };

      setResult(newResult);
      addToHistory(newResult);

    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Generation failed. Please try again.');
      if (err.message?.includes("Requested entity was not found")) {
        setShowKeyModal(true);
      }
    } finally {
      setIsGenerating(false);
    }
  };

  const restoreHistoryItem = (item: GenerationResult) => {
    setResult(item);
  };

  const reusePrompt = (itemPrompt: string) => {
    setPrompt(itemPrompt);
  };

  const handleDownload = () => {
    if (!result) return;

    const now = new Date();
    const year = now.getFullYear().toString().slice(-2);
    const month = (now.getMonth() + 1).toString().padStart(2, '0');
    const day = now.getDate().toString().padStart(2, '0');
    const dateStr = `${year}${month}${day}`;

    const storageKey = `download_seq_${dateStr}`;
    const savedSeq = localStorage.getItem(storageKey);
    let seq = savedSeq ? parseInt(savedSeq, 10) : 0;
    seq++;
    localStorage.setItem(storageKey, seq.toString());

    const seqStr = seq.toString().padStart(3, '0');

    const link = document.createElement('a');
    link.href = result.imageUrl;
    link.download = `${dateStr}_${seqStr}.png`;
    link.click();
  };

  if (!isAuthenticated) {
    return <LoginPage onLogin={() => setIsAuthenticated(true)} />;
  }

  if (!apiKey || showKeyModal) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-white p-6">
        <div className="max-w-md w-full text-center space-y-6 bg-white p-8 border border-zinc-200">
          <h1 className="text-xl font-medium tracking-tight text-zinc-800">nynk studio</h1>
          <p className="text-zinc-500 text-xs">
            Enter your Gemini API Key to access the studio.
          </p>
          <input
            type="password"
            value={tempKey}
            onChange={(e) => setTempKey(e.target.value)}
            placeholder="Paste API Key here..."
            className="w-full bg-white border border-zinc-200 p-3 text-zinc-900 text-xs outline-none focus:border-zinc-600 transition-colors rounded-none placeholder:text-zinc-300"
          />
          <button
            onClick={handleSaveKey}
            className="w-full py-3 bg-white hover:bg-zinc-50 border border-zinc-200 text-zinc-900 transition-colors text-sm font-medium rounded-none"
          >
            Enter Studio
          </button>
          <a
            href="https://aistudio.google.com/app/apikey"
            target="_blank"
            rel="noreferrer"
            className="text-xs text-zinc-400 hover:text-zinc-900 block mt-4"
          >
            Get API Key
          </a>
        </div>
      </div>
    );
  }



  return (
    <div className="min-h-screen bg-white text-zinc-900 pb-20">
      <input
        ref={fileInputRef}
        type="file"
        className="hidden"
        accept="image/png, image/jpeg"
        onChange={handleFileChange}
      />

      {/* Header */}
      <header className="border-b border-zinc-200 py-4 px-6 flex justify-between items-center bg-white sticky top-0 z-50">
        <div className="flex items-center gap-3">
          <div>
            <h1 className="text-sm font-bold tracking-tight">nynk studio</h1>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <button
            className="group flex items-center gap-2 text-zinc-400 hover:text-zinc-900 transition-colors p-2"
            onClick={() => setShowSettings(true)}
          >
            <div className="w-1.5 h-1.5 rounded-full bg-red-500"></div>
          </button>
        </div>
      </header>

      <SettingsModal
        isOpen={showSettings}
        onClose={() => setShowSettings(false)}
        imageSize={imageSize}
        setImageSize={setImageSize}
        aspectRatio={aspectRatio}
        setAspectRatio={setAspectRatio}
        onClearKey={handleClearKey}
      />

      <main className="max-w-[1600px] mx-auto px-6 mt-8 grid grid-cols-1 lg:grid-cols-12 gap-12">
        {/* Left Column: Inputs */}
        <div className="lg:col-span-4 space-y-8">
          {/* Prompt Section */}
          <section className="space-y-3">
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Describe the space, materials, and atmosphere..."
              className="w-full h-40 bg-white border border-zinc-200 p-4 text-zinc-900 focus:border-zinc-600 outline-none resize-none transition-colors placeholder:text-zinc-300 text-xs leading-relaxed rounded-none"
            />
            {/* Consistency Toggle */}
            <button
              onClick={() => setIsConsistencyFixed(!isConsistencyFixed)}
              className={`w-auto inline-flex items-center gap-3 py-2 px-3 border text-xs transition-all ${isConsistencyFixed ? 'bg-zinc-50 border-zinc-600 text-zinc-900' : 'bg-white border-zinc-200 text-zinc-400 hover:border-zinc-300'}`}
            >
              <i className={`fa-solid ${isConsistencyFixed ? 'fa-lock' : 'fa-lock-open'} text-[10px]`}></i>
              <div className={`w-1.5 h-1.5 rounded-full ${isConsistencyFixed ? 'bg-red-500' : 'bg-zinc-200'}`}></div>
            </button>


          </section>

          {/* Reference Images Section */}
          <section className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              {references.map((ref, index) => (
                <div
                  key={ref.id}
                  onClick={() => handleTriggerFile(index)}
                  onDragOver={(e) => onDragOver(e, index)}
                  onDragLeave={onDragLeave}
                  onDrop={(e) => onDrop(e, index)}
                  className={`group relative aspect-square border transition-all cursor-pointer overflow-hidden flex flex-col items-center justify-center border-zinc-200 bg-white
                        ${draggingSlot === index ? 'bg-zinc-50' : ''}`}
                >
                  <img src={ref.previewUrl} className="w-full h-full object-cover grayscale opacity-90 group-hover:opacity-100 transition-opacity" alt={`Ref ${index + 1}`} />
                  <div className="absolute inset-0 bg-white/80 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                    <span className="text-[10px] font-medium text-zinc-800">Replace</span>
                  </div>
                  {/* Remove button */}
                  <button
                    onClick={(e) => removeReference(index, e)}
                    className="absolute top-2 right-2 w-5 h-5 flex items-center justify-center bg-white border border-zinc-200 hover:border-zinc-400 text-zinc-400 hover:text-zinc-900 transition-colors z-20"
                  >
                    <i className="fa-solid fa-xmark text-[10px]"></i>
                  </button>
                </div>
              ))}

              <div
                onClick={() => handleTriggerFile(null)}
                onDragOver={(e) => onDragOver(e, 'add')}
                onDragLeave={onDragLeave}
                onDrop={(e) => onDrop(e, 'add')}
                className={`group relative aspect-square transition-all cursor-pointer overflow-hidden flex flex-col items-center justify-center dashed-border-tight hover:opacity-80
                    ${draggingSlot === 'add' ? 'bg-zinc-50' : 'bg-white'}`}
              >
                {/* Empty slot - minimalist */}
              </div>
            </div>
            <p className="text-[10px] text-zinc-400">
              Drag and drop images to guide the generation structure.
            </p>
          </section>

          {/* Action Button */}
          <button
            onClick={handleGenerate}
            disabled={isGenerating}
            className={`w-full py-4 flex items-center justify-center transition-all rounded-none border border-zinc-500
              ${isGenerating ? 'bg-zinc-50 border-zinc-200 cursor-not-allowed' : 'bg-white hover:bg-zinc-50 hover:border-zinc-400'}`}
          >
            <div className={`w-2 h-2 rounded-full transition-colors duration-500 ${isGenerating ? 'bg-zinc-400 animate-pulse' : 'bg-red-500'}`}></div>
          </button>

          {error && (
            <div className="flex items-center gap-2 mt-4 justify-center animate-in fade-in slide-in-from-top-1">
              <div className="w-1.5 h-1.5 rounded-full bg-red-500"></div>
              <span className="text-xs text-red-500 font-medium">{error.includes("quota") ? "Usage limit exceeded" : error}</span>
              <button
                onClick={() => setShowKeyModal(true)}
                className="text-[10px] text-zinc-400 underline hover:text-zinc-600 ml-2"
              >
                Change Key
              </button>
            </div>
          )}
        </div>

        {/* Right Column: Results */}
        <div className="lg:col-span-8 flex flex-col h-full">
          <div className="flex-1 min-h-[600px] border border-zinc-200 bg-zinc-50 flex flex-col relative group">
            <div className="absolute top-4 left-4 z-10 flex gap-2">
              <button
                onClick={() => setPreviewMode('fill')}
                className={`px-3 py-1.5 text-[10px] border transition-all ${previewMode === 'fill' ? 'bg-zinc-100 text-zinc-900 border-zinc-400' : 'bg-white text-zinc-500 border-zinc-200 hover:border-zinc-300'}`}
              >
                Full
              </button>
              <button
                onClick={() => setPreviewMode('fit')}
                className={`px-3 py-1.5 text-[10px] border transition-all ${previewMode === 'fit' ? 'bg-zinc-100 text-zinc-900 border-zinc-400' : 'bg-white text-zinc-500 border-zinc-200 hover:border-zinc-300'}`}
              >
                Fit
              </button>
            </div>

            {result && !isGenerating ? (
              <div className="flex-1 flex items-center justify-center p-8 bg-white">
                <div className={`relative transition-all duration-300 bg-zinc-100 ${previewMode === 'fill' ? 'w-full aspect-video' : 'h-full aspect-square'}`}>
                  <img
                    id="generated-image"
                    src={result ? `data:image/jpeg;base64,${result.imageUrl}` : undefined}
                    alt="Generated output"
                    className={`w-full h-full object-contain max-h-[70vh] ${previewMode === 'fill' ? 'object-cover' : 'object-contain'}`}
                  />


                  <div className="absolute bottom-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={handleDownload}
                      className="px-4 py-2 bg-white text-zinc-900 text-xs font-medium border border-zinc-200 hover:border-zinc-400 transition-colors"
                    >
                      Download
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center text-zinc-300 space-y-4">
                {/* Empty state - clean */}
              </div>
            )}

            {result && !isGenerating && (
              <div className="p-4 border-t border-zinc-200 bg-white flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <h4 className="text-xs font-medium text-zinc-900">Output Generated</h4>
                  <span className="text-[10px] text-zinc-300">·</span>
                  <p className="text-[10px] text-zinc-400">{imageSize} · {new Date().toLocaleTimeString()}</p>
                </div>
                <button
                  onClick={() => setResult(null)}
                  className="text-zinc-400 hover:text-zinc-900 transition-colors text-xs"
                >
                  Reset View
                </button>
                <button
                  onClick={() => reusePrompt(result.prompt)}
                  className="text-zinc-400 hover:text-zinc-900 transition-colors text-xs"
                >
                  Reuse Prompt
                </button>
              </div>
            )}
          </div>
        </div>
      </main>

      {/* History Section */}
      <section className="max-w-[1600px] mx-auto px-6 mt-16 pb-20 border-t border-zinc-100 pt-8">

        <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 gap-4">
          {history.map((item) => (
            <div key={item.timestamp} className="group relative aspect-square bg-zinc-50 border border-zinc-100 overflow-hidden cursor-pointer hover:border-zinc-300 transition-colors"
              onClick={() => restoreHistoryItem(item)}
            >
              <img src={item.imageUrl} className="w-full h-full object-cover opacity-90 group-hover:opacity-100 transition-opacity" loading="lazy" />

              {/* Hover Overlay */}
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-2 p-2">
                <button
                  onClick={(e) => { e.stopPropagation(); restoreHistoryItem(item); }}
                  className="bg-white/90 hover:bg-white text-zinc-900 text-[10px] px-2 py-1 rounded-sm w-full font-medium"
                >
                  View
                </button>
                <button
                  onClick={(e) => { e.stopPropagation(); reusePrompt(item.prompt); }}
                  className="bg-zinc-900/90 hover:bg-zinc-800 text-white text-[10px] px-2 py-1 rounded-sm w-full font-medium"
                >
                  Use Prompt
                </button>
              </div>
            </div>
          ))}
        </div>
        {history.length === 0 && (
          <div className="text-center py-10 text-xs text-zinc-300">
            No history yet.
          </div>
        )}
      </section>

      {/* Mobile Footer */}
      <footer className="fixed bottom-0 left-0 right-0 p-4 bg-white border-t border-zinc-200 lg:hidden z-50">
        <button
          onClick={handleGenerate}
          disabled={isGenerating}
          className={`w-full py-3 rounded-none font-medium text-xs border transition-all ${isGenerating ? 'bg-zinc-50 text-zinc-400 border-zinc-200' : 'bg-white text-zinc-900 border-zinc-200 hover:bg-zinc-50'}`}
        >
          {isGenerating ? 'Generating...' : 'Generate View'}
        </button>
      </footer>
    </div >
  );
};
export default App;
